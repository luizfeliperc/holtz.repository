import xbmcaddon

MainBase = 'https://pastebin.com/raw/JUVsinG0'
addon = xbmcaddon.Addon('plugin.video.Holtz-iptv')